# Planification

## Informations du Cours

- **Niveau:** 1AC
- **Matière:** Informatique
- **Unité:** programation logo
- **Leçon:** Xlogo
- **Durée:** 50 minutes
- **Semestre:** 1

---

## Semestre

1

## Sequence

- [object Object]
- [object Object]
